
import { useState,useEffect } from "react"
import axios from "axios"
import Menu from "./menu"
import LoginMenu from "./loginmenu"
const Tform=()=>{
    const [formdata,setFormData]=useState({
        'name':'',
        'username':'',
        'password':'',
        'tid':'',
        'classs':''
    })
    const [classData,setClassData] = useState([]);
    useEffect(() => {
        axios.get('http://localhost:6969/getCdata')
          .then((response) => {
            setClassData(response.data.map((ele)=>{
                return ele.name;
            }));
          })
      }, []);
    const handleSubmit= async (e)=>{
        e.preventDefault();
        console.log(formdata)
        try{
            await axios.post('http://localhost:6969/addTdata',{formdata}).then(async (res)=>{
                if(res.data == 'done'){
                    e.preventDefault();
                    try {
                        // let data = [formdata.tid,formdata.classs]
                        await axios.post('http://localhost:6969/addTtoC',{formdata});
                        alert('added to array')
                    } catch (error) {
                            alert('error')
                    }
                    alert('Data Added to DB');
                }
                else{
                    alert('error');
                }
            })
            
        }
        catch(error){
            alert('error')
        }
        window.location.reload()
    }
    return(
       <div>
        <Menu />
        <br />
        <h1>Form</h1>
        <br />
        <form onSubmit={handleSubmit}>
            <input required type="text" name="name" placeholder={'Teacher Name'} style={{width:'250px',height:'40px',fontSize:'17px'}} onChange={(e)=>setFormData({...formdata,name:e.target.value})}/>
            <br/>
            <input required type="text" name="username" placeholder={'Username'} style={{width:'250px',height:'40px',fontSize:'17px'}}  onChange={(e)=>setFormData({...formdata,username:e.target.value})}/>
            <br/>
            <input required type="password" name="password" placeholder={'Password'} style={{width:'250px',height:'40px',fontSize:'17px'}}  onChange={(e)=>setFormData({...formdata,password:e.target.value})}/>
            <br/>
            <input required type="number" name="tid" placeholder={'Teacher ID'} style={{width:'250px',height:'40px',fontSize:'17px'}}  onChange={(e)=>setFormData({...formdata,tid:e.target.value})}/>
            <br/>
            <select onChange={(e) => setFormData({ ...formdata, classs: e.target.value })}>
                <option value={'Select'}>Select</option>
            {
                
                classData.map((ele, index) => (
                    <option key={index} value={ele}>{ele}</option>
                ))
            }
        </select>
            <br/>
            <input type="submit" value="AddData" />
        </form>
       </div>
    )
}
export default Tform;