
import { useState } from "react"
import axios from "axios"
import Menu from "./menu"
import LoginMenu from "./loginmenu"
const Classform=()=>{
    const [formdata,setFormData]=useState({
        'name':'',
        'cid':'',
        'Teachers':[],
        'Students':[]
    })
    const handleSubmit= async (e)=>{
        e.preventDefault();
        console.log(formdata)
        try{
            await axios.post('http://localhost:6969/addCdata',{formdata})
            alert('Data Added to DB');
        }
        catch(error){
            alert('error')
        }
        window.location.reload()
    }
    return(
       <div>
        <Menu />
        <br />
        <h1>Form</h1>
        <br />
        <form onSubmit={handleSubmit}>
            <input required type="text" name="name" placeholder={'Class Name'} style={{width:'250px',height:'40px',fontSize:'17px'}} onChange={(e)=>setFormData({...formdata,name:e.target.value})}/>
            <br/>
            <input required type="number" name="cid" placeholder={'Class ID'} style={{width:'250px',height:'40px',fontSize:'17px'}}  onChange={(e)=>setFormData({...formdata,cid:e.target.value})}/>
            <br/>
            <input type="submit" value="AddData" />
        </form>
       </div>
    )
    
}
export default Classform;